
;                (function() {
                    window.require(["ace/snippets/c9search"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            